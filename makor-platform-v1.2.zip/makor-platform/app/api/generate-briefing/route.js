// ════════════════════════════════════════════════════════════════════════════
//   /api/generate-briefing
//
//   Server-side route handler. Takes a date, derives a deterministic mock
//   market state, asks Claude to write a Makor-house-style briefing in
//   structured JSON, validates the output, and returns it to the client.
// ════════════════════════════════════════════════════════════════════════════

import { generateMarketState } from "@/lib/marketData";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MODEL = "claude-sonnet-4-5-20250929";
const MAX_TOKENS = 8000;

// ────────────────────────────────────────────────────────────────────────────
//   Prompt construction
// ────────────────────────────────────────────────────────────────────────────

function buildSystemPrompt() {
  return `You are the senior macro strategist for Makor Securities London — an institutional FX & macro research desk. You are writing the daily Morning FX & Macro Review before the London open.

VOICE & STYLE — non-negotiable:
- Institutional. Tactical. Trader-oriented. Macro-focused.
- Like a Bloomberg / Goldman Sachs / hedge-fund desk note. Never like a blog, newsletter, or retail article.
- Use institutional shorthand and structural framing (e.g. "front-end repriced", "term-structure flattening", "carry book unwind", "risk premium re-engaging", "vega expression", "bear-flattening").
- Specific over vague. Conviction-led. No filler.
- Each piece of commentary should sound like it was written under time pressure by a real strategist who knows what matters today.

OUTPUT FORMAT — non-negotiable:
- You MUST respond with a single JSON object that conforms exactly to the schema given by the user.
- No markdown code fences. No prose before or after the JSON. The first character must be '{' and the last character must be '}'.
- All string fields must contain real, narrative content — no placeholders, no "TBD", no Lorem Ipsum.
- Numerical fields (levels, percentages, bp) must EXACTLY match the market state given in the input. Do not invent or alter numbers.
- String fields can elaborate around those numbers but must remain consistent with them.`;
}

function buildUserPrompt(market, dateInfo) {
  const m = market;
  const f = m.formatted;

  return `Generate today's Makor Morning FX & Macro Review for ${dateInfo.fullDate}.

────────────────────────────────────────────────────────
MARKET STATE (use these numbers exactly — do not alter)
────────────────────────────────────────────────────────

DOMINANT THEME: ${m.theme.label}
HEADLINE SEED:  ${m.theme.headlineSeed}
REGIME:         ${m.theme.regime.state}
PRIMARY CATALYST: ${m.theme.regime.primary}
USD DIRECTION:  ${m.theme.regime.usd}

FX (level / overnight % change):
  EUR/USD  ${m.fx.eurusd.level}  ${f.eurChg}
  GBP/USD  ${m.fx.gbpusd.level}  ${f.gbpChg}
  USD/JPY  ${m.fx.usdjpy.level}  ${f.jpyChg}
  AUD/USD  ${m.fx.audusd.level}  ${f.audChg}
  NZD/USD  ${m.fx.nzdusd.level}  ${(m.fx.nzdusd.chg >= 0 ? "+" : "") + m.fx.nzdusd.chg.toFixed(2)}%
  USD/CHF  ${m.fx.usdchf.level}  ${(m.fx.usdchf.chg >= 0 ? "+" : "") + m.fx.usdchf.chg.toFixed(2)}%
  USD/CAD  ${m.fx.usdcad.level}  ${(m.fx.usdcad.chg >= 0 ? "+" : "") + m.fx.usdcad.chg.toFixed(2)}%
  DXY      ${m.fx.dxy.level}     ${f.dxyChg}

COMMODITIES:
  Brent    $${m.commodities.brent.level}  ${f.brentChg}
  Gold     $${m.commodities.gold.level}   ${f.goldChg}

RATES:
  US 10Y   ${m.rates.us10y.level}%  ${f.us10yBp}

3M IMPLIED VOL:
  USD/JPY  ${m.vol3M.usdjpy}
  AUD/USD  ${m.vol3M.audusd}
  EUR/USD  ${m.vol3M.eurusd}
  GBP/USD  ${m.vol3M.gbpusd}
  USD/CHF  ${m.vol3M.usdchf}
  USD/CAD  ${m.vol3M.usdcad}

PRIMARY RISK EVENT (anchor the geopolitical pulse around this):
  Title:  ${m.theme.primaryRisk.title}
  Body:   ${m.theme.primaryRisk.body}
  Most exposed: ${m.theme.catalystExposed}

────────────────────────────────────────────────────────
REQUIRED OUTPUT — JSON SCHEMA
────────────────────────────────────────────────────────

Respond with EXACTLY this JSON shape. All string fields are mandatory.

{
  "volume": "247",
  "headline": "<15-word desk-style headline weaving the regime + biggest mover. NEVER generic. End without a period.>",
  "strap": "<2-sentence ~40-word strap line. Tactical framing of the session for traders.>",
  "regime": {
    "state": "${m.theme.regime.state}",
    "primary": "${m.theme.regime.primary}",
    "usd": "${m.theme.regime.usd}",
    "vol": "<one of: 'Bid · 3M' | 'Compressed' | 'Extreme' | 'Two-way' | 'Bid · 1W'>"
  },
  "riskSnapshot": [
    { "label": "Risk Sentiment", "value": "<2-3 word descriptor matching theme>", "subtitle": "<one short sentence, 12-18 words>", "dark": true },
    { "label": "Primary Catalyst", "value": "${m.theme.regime.primary}", "subtitle": "<one short sentence>", "dark": false },
    { "label": "Brent Crude", "value": "$${m.commodities.brent.level}", "subtitle": "<one short sentence on what the move means>", "dark": false },
    { "label": "USD Direction", "value": "${m.theme.regime.usd}", "subtitle": "<one short sentence>", "dark": true }
  ],
  "primaryRisk": {
    "title": "${m.theme.primaryRisk.title}",
    "body": "<rewrite this concept in your own institutional voice — 80-120 words. Use the source body as raw material but reframe and tighten. Bold key clauses with **double asterisks**.>",
    "exposed": "${m.theme.catalystExposed}",
    "vol": "<one of: 'Extreme · Wire-driven binary' | 'High intraday burst' | 'Tail risk skewed' | 'Two-way · Range-bound'>"
  },
  "marketImpact": [
    "<bullet 1: 25-35 words, leading with **bold instrument** — focus on the biggest mover>",
    "<bullet 2: 25-35 words, second-largest move>",
    "<bullet 3: 25-35 words, USD framing>",
    "<bullet 4: 25-35 words, gold or yields>",
    "<bullet 5: 25-35 words, JPY or CHF safe-haven framing>"
  ],
  "jawboning": [
    "<bullet 1, leading with **Trump:** or **Powell:** etc — 25-40 words>",
    "<bullet 2, similar — different official>",
    "<bullet 3, similar — different official>",
    "<bullet 4, similar — different official>",
    "<bullet 5, similar — different official>"
  ],
  "sinceYesterday": [
    { "tag": "Geopolitics", "h": "<8-12 word headline>", "b": "<25-40 word body>" },
    { "tag": "Energy", "h": "<8-12 word headline>", "b": "<25-40 word body>" },
    { "tag": "FX · BoJ", "h": "<8-12 word headline>", "b": "<25-40 word body>" },
    { "tag": "Rates", "h": "<8-12 word headline>", "b": "<25-40 word body>" },
    { "tag": "Equities", "h": "<8-12 word headline>", "b": "<25-40 word body>" },
    { "tag": "DXY", "h": "<8-12 word headline>", "b": "<25-40 word body>" }
  ],
  "movers": {
    "outperformers": [
      { "pair": "<pair>", "level": "<level>", "pct": "<+X.XX%>", "cmt": "<10-18 word italic-style commentary, can include **bold** lead-in>" },
      { "pair": "<pair>", "level": "<level>", "pct": "<+X.XX%>", "cmt": "<...>" },
      { "pair": "<pair>", "level": "<level>", "pct": "<+X.XX%>", "cmt": "<...>" },
      { "pair": "<pair>", "level": "<level>", "pct": "<+X.XX%>", "cmt": "<...>" }
    ],
    "underperformers": [
      { "pair": "<pair>", "level": "<level>", "pct": "<-X.XX%>", "cmt": "<...>" },
      { "pair": "<pair>", "level": "<level>", "pct": "<-X.XX%>", "cmt": "<...>" },
      { "pair": "<pair>", "level": "<level>", "pct": "<-X.XX%>", "cmt": "<...>" },
      { "pair": "<pair>", "level": "<level>", "pct": "<-X.XX%>", "cmt": "<...>" }
    ]
  },
  "regimeRead": {
    "headline": "<7-12 word italic-style desk thesis, end with full stop>",
    "body": "<35-60 words explaining the under-priced tail relative to the consensus story>"
  },
  "regimeStrip": [
    { "name": "<regime name 1>", "state": "<Active|Latent|In Transition|De-escalating>", "tone": "<green|amber|purple|red>", "body": "<20-30 word framing>" },
    { "name": "<regime name 2>", "state": "<...>", "tone": "<...>", "body": "<...>" },
    { "name": "<regime name 3>", "state": "<...>", "tone": "<...>", "body": "<...>" },
    { "name": "<regime name 4>", "state": "<...>", "tone": "<...>", "body": "<...>" }
  ],
  "volCommentary": "<70-100 word institutional commentary on the 3M IV ranking. Reference specific pairs and tenors. Emphasise where hedging flow is migrating. Use **bold** for the structural takeaway.>",
  "riskEvents": [
    {
      "severity": "critical",
      "time": "WINDOW · <description>",
      "title": "<event title>",
      "status": "<60-90 word institutional status update — use **bold** for the key fact>",
      "exposed": "<comma-separated instruments>",
      "vol": "<short vol descriptor>"
    },
    {
      "severity": "elevated",
      "time": "SCHEDULED · <time>",
      "title": "<event title>",
      "status": "<50-75 word status update>",
      "exposed": "<...>",
      "vol": "<...>"
    },
    {
      "severity": "elevated",
      "time": "STANDING · All session",
      "title": "<event title>",
      "status": "<50-75 word status update>",
      "exposed": "<...>",
      "vol": "<...>"
    }
  ],
  "deskTakes": [
    {
      "tag": "<2-3 word tag>",
      "author": "J. Marchetti",
      "role": "Head of FX Strategy",
      "time": "06:32 GMT",
      "title": "<8-14 word desk thesis ending with full stop>",
      "body": "<60-90 word strategist commentary>",
      "pin": true
    },
    {
      "tag": "<2-3 word tag>",
      "author": "C. Okafor",
      "role": "Senior FX Strategist",
      "time": "06:18 GMT",
      "title": "<8-14 word desk thesis ending with full stop>",
      "body": "<60-90 word strategist commentary>",
      "pin": false
    },
    {
      "tag": "<2-3 word tag>",
      "author": "R. Westbrook",
      "role": "Macro Strategist",
      "time": "05:54 GMT",
      "title": "<8-14 word desk thesis ending with full stop>",
      "body": "<60-90 word strategist commentary>",
      "pin": false
    }
  ],
  "playbook": [
    { "title": "<6-10 word actionable line>", "body": "<20-35 word elaboration>", "tag": "Tactical" },
    { "title": "<...>", "body": "<...>", "tag": "Risk" },
    { "title": "<...>", "body": "<...>", "tag": "Levels" },
    { "title": "<...>", "body": "<...>", "tag": "Macro" },
    { "title": "<...>", "body": "<...>", "tag": "Theme" }
  ]
}

WRITE THE BRIEFING NOW. JSON ONLY. NO PROSE OUTSIDE THE OBJECT.`;
}

// ────────────────────────────────────────────────────────────────────────────
//   Anthropic call
// ────────────────────────────────────────────────────────────────────────────

async function callAnthropic({ apiKey, system, user }) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: MAX_TOKENS,
      system,
      messages: [{ role: "user", content: user }],
    }),
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Anthropic API ${res.status}: ${errorText.slice(0, 500)}`);
  }

  const data = await res.json();
  const text = data?.content?.[0]?.text;
  if (!text) {
    throw new Error("Anthropic API returned no content block");
  }
  return text;
}

function extractJson(text) {
  // Tolerate stray whitespace and the occasional model preamble we strictly forbade
  const trimmed = text.trim();
  // Find first '{' and last '}' to slice the JSON object
  const first = trimmed.indexOf("{");
  const last = trimmed.lastIndexOf("}");
  if (first === -1 || last === -1) {
    throw new Error("No JSON object found in model output");
  }
  const slice = trimmed.slice(first, last + 1);
  return JSON.parse(slice);
}

function validateBriefing(b) {
  const required = [
    "volume",
    "headline",
    "strap",
    "regime",
    "riskSnapshot",
    "primaryRisk",
    "marketImpact",
    "jawboning",
    "sinceYesterday",
    "movers",
    "regimeRead",
    "regimeStrip",
    "volCommentary",
    "riskEvents",
    "deskTakes",
    "playbook",
  ];
  for (const k of required) {
    if (!(k in b)) throw new Error(`Briefing missing required field: ${k}`);
  }
  if (!Array.isArray(b.riskSnapshot) || b.riskSnapshot.length !== 4)
    throw new Error("riskSnapshot must be array of length 4");
  if (!Array.isArray(b.marketImpact) || b.marketImpact.length < 4)
    throw new Error("marketImpact must be array with 4+ items");
  if (!Array.isArray(b.sinceYesterday) || b.sinceYesterday.length !== 6)
    throw new Error("sinceYesterday must be array of length 6");
  if (!b.movers?.outperformers || !b.movers?.underperformers)
    throw new Error("movers must have outperformers and underperformers");
  if (!Array.isArray(b.regimeStrip) || b.regimeStrip.length !== 4)
    throw new Error("regimeStrip must be array of length 4");
  if (!Array.isArray(b.riskEvents) || b.riskEvents.length !== 3)
    throw new Error("riskEvents must be array of length 3");
  if (!Array.isArray(b.deskTakes) || b.deskTakes.length !== 3)
    throw new Error("deskTakes must be array of length 3");
  if (!Array.isArray(b.playbook) || b.playbook.length !== 5)
    throw new Error("playbook must be array of length 5");
}

// ────────────────────────────────────────────────────────────────────────────
//   Route
// ────────────────────────────────────────────────────────────────────────────

export async function POST(request) {
  try {
    const body = await request.json();
    const dateInput = body?.date;

    if (!dateInput || !/^\d{4}-\d{2}-\d{2}$/.test(dateInput)) {
      return Response.json(
        { error: "Invalid or missing 'date' (expected YYYY-MM-DD)" },
        { status: 400 }
      );
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return Response.json(
        {
          error:
            "ANTHROPIC_API_KEY is not set. Add it to .env.local or your Vercel environment variables.",
        },
        { status: 500 }
      );
    }

    // 1. Generate the deterministic market state for this date
    const market = generateMarketState(dateInput);

    // 2. Format the date for the prompt
    const dateObj = new Date(dateInput + "T06:45:00Z");
    const fullDate = dateObj.toLocaleDateString("en-GB", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    });
    const dateInfo = { fullDate, iso: dateInput };

    // 3. Call Claude
    const system = buildSystemPrompt();
    const user = buildUserPrompt(market, dateInfo);

    const startTime = Date.now();
    const rawResponse = await callAnthropic({ apiKey, system, user });
    const elapsed = Date.now() - startTime;

    // 4. Parse + validate
    let briefing;
    try {
      briefing = extractJson(rawResponse);
      validateBriefing(briefing);
    } catch (parseErr) {
      console.error("Briefing parse/validate error:", parseErr);
      console.error("Raw model output:", rawResponse.slice(0, 2000));
      return Response.json(
        {
          error: `Generated briefing did not match the expected schema: ${parseErr.message}`,
        },
        { status: 502 }
      );
    }

    // 5. Return enriched payload (briefing + raw market state for charts/tables)
    return Response.json({
      briefing,
      market,
      meta: {
        date: dateInput,
        fullDate,
        generatedAt: new Date().toISOString(),
        elapsedMs: elapsed,
        model: MODEL,
      },
    });
  } catch (err) {
    console.error("generate-briefing error:", err);
    return Response.json(
      { error: err.message || "Unknown server error" },
      { status: 500 }
    );
  }
}
