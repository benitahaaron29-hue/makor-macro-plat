# Makor Securities · Morning Intelligence Platform

Institutional FX & macro briefing workspace — a Next.js application built around the Makor Securities visual identity, with **dynamic AI-powered briefing generation**.

> **Internal product · prototype · v.1.2 · dynamic generation enabled**
> *Total Independence, Outstanding Execution.*

---

## What's new in v.1.2

The Generate Briefing button is now **live**. When the user selects a date and generates:

1. The frontend posts the date to `/api/generate-briefing`.
2. A deterministic mock-market generator (`lib/marketData.js`) seeds a per-date market state — same date always yields the same baseline.
3. The route calls Anthropic's Claude model with a strict JSON schema prompt encoding the Makor house style.
4. The structured briefing is parsed, validated, and returned to the client.
5. The dynamic viewer (`DynamicBriefingViewerPage`) renders it through the **same Makor atoms** as the static viewer — design unchanged, content fully dynamic.

Different dates produce different briefings — different headlines, regimes, market biases, risk events, desk takes, and playbooks. The static viewer remains as the fallback when opening "today's briefing" from the dashboard cards or archive.

---

## Stack

- **Next.js** 15 (App Router)
- **React** 18
- **Tailwind CSS** 3 (scaffolded — the platform itself uses inline styles by design)
- **lucide-react** for iconography
- **Lora** + **Inter** via Google Fonts
- **Anthropic Claude** for briefing generation (`claude-sonnet-4-5-20250929`)

---

## Project Structure

```
makor-platform/
├── app/
│   ├── api/
│   │   └── generate-briefing/
│   │       └── route.js     # POST — calls Claude, returns briefing JSON
│   ├── globals.css          # global resets + Tailwind base
│   ├── layout.jsx           # root HTML shell + metadata + viewport
│   └── page.jsx             # mounts <MakorPlatform />
├── components/
│   └── MakorPlatform.jsx    # the platform (all routes + dynamic viewer)
├── lib/
│   └── marketData.js        # deterministic per-date market state generator
├── public/
│   └── logo-makor.jpg       # Makor Securities logo asset
├── .env.example             # env template — copy to .env.local
├── .gitignore
├── .nvmrc                   # pins Node 20 for Vercel
├── jsconfig.json            # path aliasing — '@/components/...' and '@/lib/...'
├── next.config.mjs
├── package.json
├── postcss.config.mjs
├── README.md
├── tailwind.config.js
└── vercel.json              # framework hint + security headers
```

---

## Local Development

Requires Node 18.18+ (Node 20 recommended).

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env.local
# Edit .env.local and add your ANTHROPIC_API_KEY
# (get one at https://console.anthropic.com)

# 3. Start the dev server
npm run dev
```

Open <http://localhost:3000>, pick a date, click Generate Briefing. The first generation takes 8–15 seconds.

```bash
# Production build
npm run build
npm run start
```

---

## Deploy to Vercel

### One-time setup

1. Push this repository to GitHub.
2. Visit <https://vercel.com/new> and import the GitHub repository.
3. **Critical — add the environment variable:**
   - Vercel auto-detects Next.js. Before clicking *Deploy*, expand *Environment Variables* and add:
     - Name: `ANTHROPIC_API_KEY`
     - Value: your Anthropic key (starts with `sk-ant-api03-…`)
     - Environments: Production, Preview, Development
4. Click **Deploy**. The first build takes ~1–2 minutes.

### Updating the env var later

*Vercel → Project → Settings → Environment Variables*. After saving, redeploy from the *Deployments* tab so the new key takes effect.

### Vercel CLI alternative

```bash
npm install -g vercel
vercel login
vercel link
vercel env add ANTHROPIC_API_KEY production   # paste key when prompted
vercel --prod
```

---

## How dynamic generation works

### The market state generator (`lib/marketData.js`)

A deterministic, per-date pseudo-random state. We hash the date string into a 32-bit seed, run mulberry32, and pick from 8 pre-authored macro themes:

- Iran de-escalation rally
- Iran talks collapse · oil spike
- Fed hawkish surprise · USD bid
- BoJ confirmed intervention · JPY surge
- Hot CPI · stagflation tail
- Calm risk-on · carry rebuild
- China stimulus · AUD/CNH rally
- ECB dovish lean · EUR offered

Each theme implies a sign-and-magnitude bias for cross-asset moves. We then jitter the biases, derive levels, scale 3M IV by theme regime, and hand the whole state to the model. The result: same date → same numbers, different dates → different stories, all internally coherent.

### The API route (`app/api/generate-briefing/route.js`)

`POST /api/generate-briefing { date: "YYYY-MM-DD" }`

The route:

1. Validates the date format.
2. Generates the deterministic market state.
3. Builds a system prompt enforcing institutional voice + a user prompt embedding the market state and a strict JSON schema.
4. Calls Anthropic's Messages API server-side (the API key never reaches the browser).
5. Extracts the JSON, validates required fields, returns `{ briefing, market, meta }` to the client.

### The dynamic viewer (`DynamicBriefingViewerPage` in `MakorPlatform.jsx`)

Reuses every existing Makor atom — `SectionHead`, `SubHead`, `Pill`, `LiveDot`, `Mover`, `RiskEventCard`, `BriefingActionBar`, `BriefingEnd` — driven entirely by the briefing JSON. A tiny `<MD>` renderer handles the `**bold**` markdown the prompt produces. Design is identical to the static viewer; only content differs.

The static viewer remains for non-generated entry points (dashboard "Open" button, archive items).

---

## Routing

| Route state | Component                        | Entry points                              |
| ----------- | -------------------------------- | ----------------------------------------- |
| `dashboard` | `Dashboard`                      | Sidebar · default landing                 |
| `archive`   | `ArchivePage`                    | Sidebar                                   |
| `sources`   | `SourcesPage`                    | Sidebar                                   |
| `briefing`  | `DynamicBriefingViewerPage` if `briefingData` set, else `BriefingViewerPage` | "Generate Briefing" CTA · "Open" links · archive items |

---

## Notes for production

- **API key safety.** The Anthropic key is read from `process.env.ANTHROPIC_API_KEY` server-side only. It is never bundled into the client and never sent to the browser.
- **Rate limiting.** The route is unmetered. For a real internal deployment, add rate limiting (e.g. `@upstash/ratelimit`) keyed on user/session before exposing publicly.
- **Generation time.** Typical generation is 8–15s. For longer-form requests consider streaming via `stream: true` in the Anthropic call and SSE on the route — the current synchronous approach was chosen for simplicity and matches the existing "Compiling…" UX.
- **Caching.** The briefing JSON is not cached. For repeat-date requests, consider stashing into the existing archive store and serving from there on subsequent calls.
- **Error handling.** If the API fails (no key, rate limit, parse error), the dashboard shows a Makor-styled error box and the generate button stays available. The static viewer still works — clicking "Open" on the dashboard cards goes to today's pre-authored briefing.
- **Responsive behaviour.** Desktop-first institutional layout preserved. `globals.css` enforces `min-width: 1280px` with horizontal scroll below that breakpoint.

---

## License

Internal Makor Group property. Not for redistribution.

© 2026 Makor Group · FCA Regulation 625054
